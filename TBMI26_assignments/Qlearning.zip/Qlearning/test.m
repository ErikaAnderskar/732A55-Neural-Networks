
%%
%Initilize world/state
world = 4;
gwinit(world);
state_prev = gwstate()
pos_prev = state_prev.pos;
% Initilize lookup table/Qmatrix
look_up = ones(10,15,4)*(-1);

% init values
eps = 0.9;
a_prev = chooseaction(look_up, pos_prev(1), pos_prev(2), [1 2 3 4], [1 1 1 1], eps);
alpha = 0.25;
gamma = 0.9;


var = [];

gwdraw()

%%
look_up(10,:,1) = -10000 %init lowest row to -100 for action down
look_up(1,:,2) = -10000 %init highest row to -100 for action up
look_up(:,15,3) = -10000 %init right row to -100 for action right
look_up(:,1,4) = -10000 %init left row to -100 for action left

if world == 1
    look_up(3,13,1) = 0
    look_up(5,13,2) = 0
    look_up(4,12,3) = 0 
    look_up(4,14,4) = 0
end

if world == 2
    look_up(3,15,1) = 0 %down
    look_up(5,15,2) = 0 %up
    look_up(4,14,3) = 0 %right
    %look_up(4,14,4) = 0 %left
end

if world == 3
    look_up(9,14,1) = 0 %down
    %look_up(5,15,2) = 0 %up
    look_up(10,13,3) = 0 %right
    look_up(10,15,4) = 0 %left
end

if world == 4
    look_up(7,2,1) = 0 %down
    look_up(9,2,2) = 0 %up
    look_up(8,1,3) = 0 %right
    look_up(8,3,4) = 0 %left
end

%%

tic
for epoch = 1:10000
gwinit(world);
state_prev = gwstate();
pos_prev = state_prev.pos;
isTerminal = state_prev.isterminal();
step = 0;
%epoch
while isTerminal == false
step = step + 1;
%r = state.feedback;
Q_prev = look_up(pos_prev(1),pos_prev(2),a_prev);

%a = sample([1 2 3 4], [0.25 0.25 0.25 0.25])
[a, oa] = chooseaction(look_up, pos_prev(1), pos_prev(2), [1 2 3 4], [1 1 1 1], eps);
act = gwaction(a);

% If the robot bumps into a wall --> change action 
while act.isvalid ~= 1 
    [a, oa] = chooseaction(look_up, pos_prev(1), pos_prev(2), [1 2 3 4], [1 1 1 1], eps);
    act = gwaction(a);
end

r = act.feedback;
state = gwstate();
pos = state.pos;
isTerminal = state.isterminal();

look_up(pos_prev(1), pos_prev(2), a) = ((1-alpha)*Q_prev)+alpha*(r+gamma*max(look_up(pos(1), pos(2), :)));

var(step) = a;
pos_prev = pos;
state_prev = state;
a_prev = a;

%gwdraw()
end

if mod(epoch, 19000) == 0
    eps = eps - 0;
end

%eps = eps - 0.0001
if mod(epoch, 1000) == 0
    epoch
end


end

toc
%%


