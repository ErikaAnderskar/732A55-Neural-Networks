%
% run script to setup the lab paths
%

addpath(pwd)
addpath data
addpath helpFunctions
addpath kNN
addpath multiLayerNetwork
addpath singleLayerNetwork
